<?php
require "config.php";
xhtml_head("ERROR 404 !");
echo "<div class=\"error\">你的请求无法找到 - ERROR 404 !</div>";
xhtml_footer();
?>
